CREATE TABLE customers1  
( customer_id number(10) NOT NULL,  
  customer_name varchar2(50) NOT NULL,  
  city varchar2(50)  
);  


INSERT INTO customers  
(customer_id, customer_name,city)  
VALUES  
(100, 'Narendra','chennai');  

commit


CREATE TABLE  IMGTABLE   
   (    NAME  VARCHAR2(4000),   
    PHOTO BLOB  
   )  
  

   CREATE TABLE  FILETABLE1  
   (    ID NUMBER,   
    NAME CLOB  
   )  







